package Dictionary;

import java.io.*;
import java.util.*;
import javafx.application.Platform;

/**
 * A Thread that contains the application we are going to animate
 *
 */
public class MisspellActionThread implements Runnable {

    DictionaryController controller;
    private final String textFileName;
    private final String dictionaryFileName;

    private LinesToDisplay myLines;
    private DictionaryInterface<String, String> myDictionary;
    private boolean dictionaryLoaded;

    /**
     * Constructor for objects of class MisspellActionThread
     *
     * @param controller
     */
    public MisspellActionThread(DictionaryController controller) {
        super();

        this.controller = controller;
        textFileName = "check.txt";
        dictionaryFileName = "sampleDictionary.txt";

        myDictionary = new HashedMapAdaptor<String, String>();
        myLines = new LinesToDisplay();
        dictionaryLoaded = false;

    }

    @Override
    public void run() {
//        Wordlet plchldr= new Wordlet ("abc",true);
//        myLines.addWordlet(plchldr);// EXCEPTION THREAD THROWN HERE
//        myLines.nextLine();
//        showLines(myLines);
//        myLines.addWordlet(new Wordlet("def", false));
//        showLines(myLines);
//        myLines.nextLine();
        // ADD CODE HERE TO LOAD DICTIONARY
        
        loadDictionary( dictionaryFileName , myDictionary);
        Platform.runLater(() -> {
            if (dictionaryLoaded) {
               controller.SetMsg("The Dictionary has been loaded"); 
            } else {
               controller.SetMsg("No Dictionary is loaded"); 
            }
        });
        
        // ADD CODE HERE TO CALL checkWords
        checkWords(textFileName, myDictionary);
        

    }

    /**
     * Load the words into the dictionary.
     *
     * @param theFileName The name of the file holding the words to put in the
     * dictionary.
     * @param theDictionary The dictionary to load.
     */
    public void loadDictionary(String theFileName, DictionaryInterface<String, String> theDictionary) {
        Scanner input;
        try {
            String inString;
            String correctWord;

            input = new Scanner(new File(theFileName));

            // ADD CODE HERE TO READ WORDS INTO THE DICTIONARY     
            while (input.hasNextLine()){Scanner scn = new Scanner(input.nextLine());
                while(scn.hasNext()){
                String line =scn.next();
                System.out.println(line);
                inString= line;
                correctWord ="";
                theDictionary.add(inString,correctWord );
                }
            }
        dictionaryLoaded= true;    
            
        } catch (IOException e) {
            System.out.println("There was an error in reading or opening the file: " + theFileName);
            System.out.println(e.getMessage());
        }

    }
  
    /**
     * Get the words to check, check them, then put Wordlets into myLines. When
     * a single line has been read do an animation step to wait for the user.
     *
     */
    public void checkWords(String theFileName, DictionaryInterface<String, String> theDictionary) {
        Scanner input;
        String inString;
        String tmpword;

        
        
        try { input = new Scanner(new File(theFileName));
            while (input.hasNextLine()){
            String newLine= input.nextLine();
            StringTokenizer word = new StringTokenizer(newLine);
            while(word.hasMoreTokens()){
                
                char[]arry=word.nextToken().toCharArray();
                int j=0;
                int k=0;
                
                
                for(int i=0;i<arry.length;i++){
                    arry[j]=arry[i];
                    
                    if((arry[i]!='\'')&&(!(Character.isLetter(arry[i])))){
                
                        j--;
                        k++;
                    }
                    j++;
                }
               arry= Arrays.copyOfRange(arry, 0, arry.length-k);
                tmpword=new String(arry);
            myLines.addWordlet(new Wordlet(tmpword,checkWord(tmpword,theDictionary)));
            showLines(myLines);
            
            }
            myLines.nextLine();
            } 
            
            
            
        } catch (IOException e) {
            System.out.println("There was an error in reading or opening the file: " + theFileName);
            System.out.println(e.getMessage());
        }
        
    }

    /**
     * Check the spelling of a single word.
     *
     */
    public boolean checkWord(String word, DictionaryInterface<String, String> theDictionary) {
        boolean result = false;
        result=theDictionary.contains(word);
        // ADD CODE HERE    

        
        

        return result;

    }

    private void showLines(LinesToDisplay lines) {
        try {
            Thread.sleep(500);
            Platform.runLater(() -> {
                if (myLines != null) {
                    controller.UpdateView(lines);
                }
            });
        } catch (InterruptedException ex) {
        }
    }

} // end class MisspellActionThread

